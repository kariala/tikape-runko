
package com.tikape.keskustelupalsta.dao;

import com.tikape.keskustelupalsta.domain.Viesti;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ViestiDao implements Dao<Viesti, String> {
    private Database database;
    
    public ViestiDao(Database database) {
        this.database = database;
    }

    @Override
    public Viesti create(Viesti t) throws SQLException {
        this.database.getConnection().createStatement().execute("INSERT INTO Viesti (ketju_id, sisalto, nimimerkki) VALUES('" + t.getKetju().getId() + "','" + t.getSisalto() + "','" + t.getNimimerkki() + "')");
        return new Viesti(t.getKetju(),t.getSisalto(), t.getNimimerkki());
    }

    @Override
    public Viesti findOne(String key) throws SQLException {
        for (Viesti viesti : this.findAll()) {
            if (viesti.getId() == Integer.parseInt(key)) {
                return viesti;
            }
        }
        return null;
    }

    @Override
    public List<Viesti> findAll() throws SQLException {
        List<Viesti> kaikkiViestit = new ArrayList();
        ResultSet kaikki = this.database.getConnection().createStatement().executeQuery("SELECT * FROM Viesti");
        KetjuDao ketjudao = new KetjuDao(database);
        while (kaikki.next()) {
            Viesti a = new Viesti(kaikki.getInt("id"), ketjudao.findOne(kaikki.getString("ketju_id")), kaikki.getString("sisalto"), kaikki.getString("nimimerkki"));
            kaikkiViestit.add(a);
        }
        return kaikkiViestit;
    }

    @Override
    public void update(String key, Viesti t) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void delete(String key) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
