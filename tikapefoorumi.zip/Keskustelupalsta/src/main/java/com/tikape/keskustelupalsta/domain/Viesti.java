
package com.tikape.keskustelupalsta.domain;

public class Viesti {
    private Integer id;
    private Ketju ketju;
    private String sisalto;
    private String nimimerkki;
    
    public Viesti(Integer id, Ketju ketju, String sisalto, String nimimerkki) {
        this.id = id;
        this.ketju = ketju;
        this.sisalto = sisalto;
        this.nimimerkki = nimimerkki;
    }
    
    public Viesti(Ketju ketju, String sisalto, String nimimerkki) {
        this(null, ketju, sisalto, nimimerkki);
    }
    
    public Viesti(String sisalto, String nimimerkki) {
        this(null, null, sisalto, nimimerkki);
    }

    public String getNimimerkki() {
        return nimimerkki;
    }

    public void setNimimerkki(String nimimerkki) {
        this.nimimerkki = nimimerkki;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Ketju getKetju() {
        return ketju;
    }

    public void setKetju(Ketju ketju) {
        this.ketju = ketju;
    }

    public String getSisalto() {
        return sisalto;
    }

    public void setSisalto(String sisalto) {
        this.sisalto = sisalto;
    }   
}
