CREATE TABLE Alue (
    id integer AUTO_INCREMENT PRIMARY KEY,
    name varchar(50)
);

CREATE TABLE Ketju (
    id integer AUTO_INCREMENT PRIMARY KEY,
    alue_id integer NOT NULL,
    name varchar(50),
    FOREIGN KEY (alue_id) REFERENCES Alue(id)
);

CREATE TABLE Viesti (
    id integer AUTO_INCREMENT PRIMARY KEY,
    ketju_id integer NOT NULL,
    sisalto varchar(200),
    nimimerkki varchar(20),
    FOREIGN KEY (ketju_id) REFERENCES Ketju(id)
);